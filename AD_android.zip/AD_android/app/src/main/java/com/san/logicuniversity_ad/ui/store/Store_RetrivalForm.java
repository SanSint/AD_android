package com.san.logicuniversity_ad.ui.store;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.san.logicuniversity_ad.AsyncToServer;
import com.san.logicuniversity_ad.BuildConfig;
import com.san.logicuniversity_ad.Command;
import com.san.logicuniversity_ad.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Store_RetrivalForm extends AppCompatActivity
        implements View.OnClickListener, AsyncToServer.IServerResponse {

    private final String GET_ZONES_URL = BuildConfig.API_BASE_URL + "/store/zones";

    Spinner zoneFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_retrival_form);

        zoneFilter = findViewById(R.id.zone_fliter);
        zoneFilter.setSelection(0);

        Button btn = findViewById(R.id.btn_submit);
        btn.setOnClickListener(this);

        requestZones();

    }

    public void onClick(View v) {
        Intent view = new Intent(this, Store_Success.class);
        startActivity(view);
    }

    private void requestZones() {
        Command cmd = new Command(this, "getZones", GET_ZONES_URL, null);
        new AsyncToServer().execute(cmd);
    }

    @Override
    public void onServerResponse(JSONObject jsonObj) {
        if (jsonObj == null) {
            return;
        }

        try {
            String context = (String) jsonObj.get("context");

            if (context.compareTo("getZones") == 0) {
                ArrayList<String> zoneList = new ArrayList<>();
                zoneList.add("All");
                JSONArray zonesJArr = (JSONArray) jsonObj.get("result");

                for (int i = 0, count = zonesJArr.length(); i < count; i++) {
                    zoneList.add(zonesJArr.getString(i));
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item, zoneList);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                zoneFilter.setAdapter(adapter);
                zoneFilter.setSelection(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
